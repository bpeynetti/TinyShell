echo "The world is not always good..." > test1.txt
echo "short filename" > text2.txt
echo "medium length file...." > test.3
echo "a little longer........ with ls string" > test.4
echo -e "this contains one ls, \ntwo ls s \nthree lss " > test.5
echo -e "a little little longer....\ncat exit\ncat" > test.20
echo -e "test cases number 23" > test.23
echo -e "test cases number 200" > test.200
echo "no no no no..." > dummy
echo -e "longlist\ntxt\n2 test\n2 world\n3 test\n2 test" > longlist.txt
echo -e "cat ext\ncat\ncat\ndog exit\ncat exit\n" > cat.txtt
touch dogexit.txt
touch catdogexit.txt
touch dogcatexit.exit
